"""Reserved ``T`` construction surface.

Typed operation constructors are deliberately not implemented in M0.  Named
stubs provide an explicit capability error instead of accepting an opaque
payload; semantic constructors arrive in M1.
"""

from __future__ import annotations

from typing import NoReturn

from .errors import UnsupportedError


def _unavailable(*_args: object, **_kwargs: object) -> NoReturn:
    raise UnsupportedError("typed T.* construction is scheduled for M1")


value = _unavailable
pipeline = _unavailable
copy = _unavailable
gemm = _unavailable
reduce = _unavailable
elementwise = _unavailable
aligned = _unavailable
endpoint = _unavailable
depends = _unavailable
program = _unavailable

__all__ = [
    "aligned",
    "copy",
    "depends",
    "elementwise",
    "endpoint",
    "gemm",
    "pipeline",
    "program",
    "reduce",
    "value",
]
