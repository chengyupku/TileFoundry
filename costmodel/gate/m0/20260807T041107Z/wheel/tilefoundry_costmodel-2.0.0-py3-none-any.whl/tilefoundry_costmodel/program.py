"""Immutable typed-program boundary records.

M0 only establishes the records and their schema discriminator.  Operation
lowering, relation expansion, and the ``T.*`` semantic constructors are
intentionally deferred to M1.
"""

from __future__ import annotations

from dataclasses import dataclass
from enum import Enum
from typing import TypeAlias

from .constants import PROGRAM_SCHEMA_VERSION
from .errors import InvalidRequestError, WorkloadError
from .model import (
    LoopId,
    NamedShape,
    OpId,
    ProgramId,
    TensorDescriptor,
    ValueId,
    WorkloadKind,
    validate_identifier,
)


class MemorySpace(str, Enum):
    """Name a B200-visible value storage space."""

    GLOBAL = "global"
    SHARED = "shared"
    TENSOR = "tensor"
    REGISTER = "register"


class TileOpKind(str, Enum):
    """Discriminate one typed tile operation."""

    COPY = "copy"
    GEMM = "gemm"
    REDUCE = "reduce"
    ELEMENTWISE = "elementwise"


class ReductionKind(str, Enum):
    """Name a reduction function."""

    SUM = "sum"
    MAX = "max"


class ElementwiseKind(str, Enum):
    """Name a calibrated elementwise function."""

    ADD = "add"
    MULTIPLY = "multiply"
    DIVIDE = "divide"
    EXP = "exp"
    RELU = "relu"
    GELU = "gelu"
    SILU = "silu"
    CAUSAL_MASK = "causal_mask"


class DependencyRelationKind(str, Enum):
    """Discriminate one operation-instance relation."""

    ALIGNED = "aligned"
    ENDPOINT = "endpoint"


class InstanceEndpoint(str, Enum):
    """Select a first or last operation instance."""

    FIRST = "first"
    LAST = "last"


@dataclass(frozen=True, slots=True)
class AlignedRelation:
    kind: DependencyRelationKind
    iteration_distance: int

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", DependencyRelationKind)
        if self.kind is not DependencyRelationKind.ALIGNED:
            raise WorkloadError("aligned relation kind must be 'aligned'")
        if (
            isinstance(self.iteration_distance, bool)
            or not isinstance(self.iteration_distance, int)
            or self.iteration_distance < 0
        ):
            raise WorkloadError("iteration_distance must be a non-negative integer")


@dataclass(frozen=True, slots=True)
class EndpointRelation:
    kind: DependencyRelationKind
    src_endpoint: InstanceEndpoint
    dst_endpoint: InstanceEndpoint

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", DependencyRelationKind)
        _coerce_enum(self, "src_endpoint", InstanceEndpoint)
        _coerce_enum(self, "dst_endpoint", InstanceEndpoint)
        if self.kind is not DependencyRelationKind.ENDPOINT:
            raise WorkloadError("endpoint relation kind must be 'endpoint'")


DependencyRelation: TypeAlias = AlignedRelation | EndpointRelation


@dataclass(frozen=True, slots=True)
class LoopBarrier:
    barrier_id: str
    src_loop_id: LoopId
    dst_loop_id: LoopId

    def __post_init__(self) -> None:
        _program_identifier(self.barrier_id, "barrier_id")
        _program_identifier(self.src_loop_id, "src_loop_id")
        _program_identifier(self.dst_loop_id, "dst_loop_id")
        if self.src_loop_id == self.dst_loop_id:
            raise WorkloadError("loop barrier endpoints must be distinct")


@dataclass(frozen=True, slots=True)
class TileValueType:
    tensor: TensorDescriptor
    memory_space: MemorySpace

    def __post_init__(self) -> None:
        if not isinstance(self.tensor, TensorDescriptor):
            raise WorkloadError("value tensor must be TensorDescriptor")
        _coerce_enum(self, "memory_space", MemorySpace)


@dataclass(frozen=True, slots=True)
class TileValue:
    value_id: ValueId
    value_type: TileValueType

    def __post_init__(self) -> None:
        _program_identifier(self.value_id, "value_id")
        if not isinstance(self.value_type, TileValueType):
            raise WorkloadError("value_type must be TileValueType")


@dataclass(frozen=True, slots=True)
class TileLoop:
    loop_id: LoopId
    iterations: int

    def __post_init__(self) -> None:
        _program_identifier(self.loop_id, "loop_id")
        if (
            isinstance(self.iterations, bool)
            or not isinstance(self.iterations, int)
            or self.iterations <= 0
        ):
            raise WorkloadError("loop iterations must be positive")


@dataclass(frozen=True, slots=True)
class OpIterationDomain:
    loop_id: LoopId | None
    first_iteration: int
    iteration_count: int

    def __post_init__(self) -> None:
        if (
            isinstance(self.first_iteration, bool)
            or not isinstance(self.first_iteration, int)
            or self.first_iteration < 0
        ):
            raise WorkloadError("first_iteration must be non-negative")
        if (
            isinstance(self.iteration_count, bool)
            or not isinstance(self.iteration_count, int)
            or self.iteration_count <= 0
        ):
            raise WorkloadError("iteration_count must be positive")
        if self.loop_id is None:
            if (self.first_iteration, self.iteration_count) != (0, 1):
                raise WorkloadError("a one-time domain must equal (None, 0, 1)")
        else:
            _program_identifier(self.loop_id, "loop_id")


@dataclass(frozen=True, slots=True)
class CopyOp:
    kind: TileOpKind
    op_id: OpId
    source: ValueId
    destination: ValueId
    domain: OpIterationDomain

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", TileOpKind)
        _check_op_kind(self.kind, TileOpKind.COPY)
        _validate_op_id(self.op_id)
        _program_identifier(self.source, "source")
        _program_identifier(self.destination, "destination")
        _require_domain(self.domain)


@dataclass(frozen=True, slots=True)
class GemmOp:
    kind: TileOpKind
    op_id: OpId
    lhs: ValueId
    rhs: ValueId
    accumulator: ValueId
    result: ValueId
    m_axis: str
    n_axis: str
    k_axis: str
    domain: OpIterationDomain

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", TileOpKind)
        _check_op_kind(self.kind, TileOpKind.GEMM)
        _validate_op_id(self.op_id)
        for name in ("lhs", "rhs", "accumulator", "result"):
            _program_identifier(getattr(self, name), name)
        for name in ("m_axis", "n_axis", "k_axis"):
            _program_identifier(getattr(self, name), name)
        _require_domain(self.domain)


@dataclass(frozen=True, slots=True)
class ReduceOp:
    kind: TileOpKind
    op_id: OpId
    source: ValueId
    result: ValueId
    axes: tuple[str, ...]
    reduction: ReductionKind
    domain: OpIterationDomain

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", TileOpKind)
        _check_op_kind(self.kind, TileOpKind.REDUCE)
        _validate_op_id(self.op_id)
        _program_identifier(self.source, "source")
        _program_identifier(self.result, "result")
        axes = tuple(self.axes)
        object.__setattr__(self, "axes", axes)
        if not axes or len(axes) != len(set(axes)):
            raise WorkloadError("reduction axes must be non-empty and unique")
        for axis in axes:
            _program_identifier(axis, "reduction axis")
        _coerce_enum(self, "reduction", ReductionKind)
        _require_domain(self.domain)


@dataclass(frozen=True, slots=True)
class ElementwiseOp:
    kind: TileOpKind
    op_id: OpId
    inputs: tuple[ValueId, ...]
    result: ValueId
    function: ElementwiseKind
    domain: OpIterationDomain

    def __post_init__(self) -> None:
        _coerce_enum(self, "kind", TileOpKind)
        _check_op_kind(self.kind, TileOpKind.ELEMENTWISE)
        _validate_op_id(self.op_id)
        inputs = tuple(self.inputs)
        object.__setattr__(self, "inputs", inputs)
        if not inputs:
            raise WorkloadError("elementwise operation requires an input")
        for value_id in inputs:
            _program_identifier(value_id, "elementwise input")
        _program_identifier(self.result, "result")
        _coerce_enum(self, "function", ElementwiseKind)
        _require_domain(self.domain)


TileOp: TypeAlias = CopyOp | GemmOp | ReduceOp | ElementwiseOp


@dataclass(frozen=True, slots=True)
class TileDependency:
    value_id: ValueId
    src_op_id: OpId
    dst_op_id: OpId
    relation: DependencyRelation

    def __post_init__(self) -> None:
        for value, label in (
            (self.value_id, "value_id"),
            (self.src_op_id, "src_op_id"),
            (self.dst_op_id, "dst_op_id"),
        ):
            _program_identifier(value, label)
        if not isinstance(self.relation, (AlignedRelation, EndpointRelation)):
            raise WorkloadError("dependency relation must be typed")


@dataclass(frozen=True, slots=True)
class TileCandidate:
    tile_id: str
    shape: NamedShape

    def __post_init__(self) -> None:
        _program_identifier(self.tile_id, "tile_id")
        if not isinstance(self.shape, NamedShape):
            raise WorkloadError("tile shape must be NamedShape")


@dataclass(frozen=True, slots=True)
class TileProgram:
    """One concrete typed program variant.

    Nested operation records are data-only in M0; semantic lowering is deferred
    to the next milestone.
    """

    schema_version: int
    program_id: ProgramId
    workload_kind: WorkloadKind
    tile: TileCandidate
    values: tuple[TileValue, ...]
    loops: tuple[TileLoop, ...]
    operations: tuple[TileOp, ...]
    dependencies: tuple[TileDependency, ...]
    loop_barriers: tuple[LoopBarrier, ...]
    inputs: tuple[ValueId, ...]
    outputs: tuple[ValueId, ...]

    def __post_init__(self) -> None:
        if (
            isinstance(self.schema_version, bool)
            or not isinstance(self.schema_version, int)
            or self.schema_version != PROGRAM_SCHEMA_VERSION
        ):
            raise WorkloadError(f"unsupported program schema version: {self.schema_version!r}")
        _program_identifier(self.program_id, "program_id")
        _coerce_enum(self, "workload_kind", WorkloadKind)
        if not isinstance(self.tile, TileCandidate):
            raise WorkloadError("program tile must be TileCandidate")
        values = tuple(self.values)
        loops = tuple(self.loops)
        operations = tuple(self.operations)
        dependencies = tuple(self.dependencies)
        barriers = tuple(self.loop_barriers)
        inputs = tuple(self.inputs)
        outputs = tuple(self.outputs)
        object.__setattr__(self, "values", values)
        object.__setattr__(self, "loops", loops)
        object.__setattr__(self, "operations", operations)
        object.__setattr__(self, "dependencies", dependencies)
        object.__setattr__(self, "loop_barriers", barriers)
        object.__setattr__(self, "inputs", inputs)
        object.__setattr__(self, "outputs", outputs)
        if not all(isinstance(item, TileValue) for item in values):
            raise WorkloadError("program values must contain TileValue records")
        if not all(isinstance(item, TileLoop) for item in loops):
            raise WorkloadError("program loops must contain TileLoop records")
        if not all(
            isinstance(item, (CopyOp, GemmOp, ReduceOp, ElementwiseOp)) for item in operations
        ):
            raise WorkloadError("program operations must contain typed operation records")
        if not all(isinstance(item, TileDependency) for item in dependencies):
            raise WorkloadError("program dependencies must contain TileDependency records")
        if not all(isinstance(item, LoopBarrier) for item in barriers):
            raise WorkloadError("program loop_barriers must contain LoopBarrier records")
        for value_id in inputs:
            _program_identifier(value_id, "program input")
        for value_id in outputs:
            _program_identifier(value_id, "program output")
        for collection, label in ((values, "value"), (loops, "loop"), (operations, "operation")):
            ids = tuple(
                str(getattr(item, f"{label}_id" if label != "operation" else "op_id"))
                for item in collection
            )
            if len(ids) != len(set(ids)):
                raise WorkloadError(f"program {label} IDs must be unique")

    def to_json(self) -> str:
        from ._serialization import program_to_json

        return program_to_json(self)

    @classmethod
    def from_json(cls, text: str) -> "TileProgram":
        from ._serialization import program_from_json

        return program_from_json(text)


def _coerce_enum(instance: object, field_name: str, enum_type: type[Enum]) -> None:
    value = getattr(instance, field_name)
    if isinstance(value, enum_type):
        return
    try:
        object.__setattr__(instance, field_name, enum_type(value))
    except (TypeError, ValueError) as exc:
        raise WorkloadError(f"invalid {field_name}") from exc


def _check_op_kind(value: object, expected: TileOpKind) -> None:
    if not isinstance(value, TileOpKind):
        try:
            value = TileOpKind(value)
        except (TypeError, ValueError) as exc:
            raise WorkloadError("unknown tile operation kind") from exc
    if value is not expected:
        raise WorkloadError(f"operation kind must be {expected.value!r}")


def _validate_op_id(value: OpId) -> None:
    _program_identifier(value, "op_id")


def _program_identifier(value: object, label: str) -> None:
    if not isinstance(value, str):
        raise WorkloadError(f"{label} must be a non-empty ASCII string")
    try:
        validate_identifier(value, label=label)
    except InvalidRequestError as exc:
        raise WorkloadError(str(exc)) from exc


def _require_domain(value: object) -> None:
    if not isinstance(value, OpIterationDomain):
        raise WorkloadError("operation domain must be OpIterationDomain")


__all__ = [
    "AlignedRelation",
    "CopyOp",
    "DependencyRelation",
    "DependencyRelationKind",
    "ElementwiseKind",
    "ElementwiseOp",
    "EndpointRelation",
    "GemmOp",
    "InstanceEndpoint",
    "LoopBarrier",
    "MemorySpace",
    "OpIterationDomain",
    "ReduceOp",
    "ReductionKind",
    "TileCandidate",
    "TileDependency",
    "TileLoop",
    "TileOp",
    "TileOpKind",
    "TileProgram",
    "TileValue",
    "TileValueType",
]
