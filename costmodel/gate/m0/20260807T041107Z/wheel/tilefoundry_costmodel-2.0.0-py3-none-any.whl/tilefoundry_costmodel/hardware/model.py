"""Immutable hardware schema records for the version 2 boundary.

The records describe a schema document only.  Authoritative B200 facts and
catalog construction remain future-milestone responsibilities.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass
from enum import Enum
from typing import TypeVar

from ..constants import HARDWARE_SCHEMA_VERSION
from ..errors import HardwareSpecError
from ..model import DType, HardwareSpecRef, ResourceId


class FactOrigin(str, Enum):
    """Name the provenance class of one capacity fact."""

    VENDOR = "vendor"
    MEASURED = "measured"
    DERIVED = "derived"
    CONSERVATIVE = "conservative"
    UNAVAILABLE = "unavailable"


class StaticUnit(str, Enum):
    """Name a static capacity unit."""

    BYTES = "bytes"
    REGISTERS_32BIT = "registers_32bit"
    WARPS = "warps"
    SLOTS = "slots"


@dataclass(frozen=True, slots=True)
class FactProvenance:
    """Explain the origin and conditions of one hardware fact."""

    origin: FactOrigin
    source: str
    conditions: str

    def __post_init__(self) -> None:
        _coerce_enum(self, "origin", FactOrigin)
        _hardware_string(self.source, "provenance source")
        _hardware_string(self.conditions, "provenance conditions")
        if self.origin is FactOrigin.UNAVAILABLE:
            raise HardwareSpecError("unavailable facts cannot define a capacity")


@dataclass(frozen=True, slots=True)
class TemporalResourceSpec:
    """Describe one schedulable temporal resource."""

    resource_id: ResourceId
    capacity_slots: int
    description: str
    provenance: FactProvenance

    def __post_init__(self) -> None:
        _hardware_identifier(self.resource_id, "resource_id")
        _positive_int(self.capacity_slots, "capacity_slots")
        _hardware_string(self.description, "resource description")
        if not isinstance(self.provenance, FactProvenance):
            raise HardwareSpecError("resource provenance must be FactProvenance")


@dataclass(frozen=True, slots=True)
class StaticResourceSpec:
    """Describe one per-CTA static capacity."""

    resource_id: ResourceId
    capacity_units: int
    unit: StaticUnit
    description: str
    provenance: FactProvenance

    def __post_init__(self) -> None:
        _hardware_identifier(self.resource_id, "resource_id")
        _positive_int(self.capacity_units, "capacity_units")
        _coerce_enum(self, "unit", StaticUnit)
        _hardware_string(self.description, "resource description")
        if not isinstance(self.provenance, FactProvenance):
            raise HardwareSpecError("resource provenance must be FactProvenance")


@dataclass(frozen=True, slots=True)
class HardwareSpec:
    """Schema-shaped hardware document without B200 fact resolution."""

    ref: HardwareSpecRef
    architecture: str
    temporal_resources: tuple[TemporalResourceSpec, ...]
    static_resources: tuple[StaticResourceSpec, ...]
    supported_dtypes: tuple[DType | str, ...]
    supported_implementation_ids: tuple[str, ...]
    schema_version: int = HARDWARE_SCHEMA_VERSION

    def __post_init__(self) -> None:
        if not isinstance(self.ref, HardwareSpecRef):
            raise HardwareSpecError("hardware ref must be HardwareSpecRef")
        _hardware_string(self.architecture, "architecture")
        if (
            isinstance(self.schema_version, bool)
            or not isinstance(self.schema_version, int)
            or self.schema_version != HARDWARE_SCHEMA_VERSION
        ):
            raise HardwareSpecError(f"unsupported hardware schema version: {self.schema_version!r}")

        temporal = tuple(_coerce_temporal_resource(item) for item in self.temporal_resources)
        static = tuple(_coerce_static_resource(item) for item in self.static_resources)
        object.__setattr__(self, "temporal_resources", temporal)
        object.__setattr__(self, "static_resources", static)
        _unique_ids(temporal, "resource_id", "temporal resource IDs")
        _unique_ids(static, "resource_id", "static resource IDs")

        dtypes: list[DType] = []
        for value in self.supported_dtypes:
            try:
                dtype = value if isinstance(value, DType) else DType(value)
            except (TypeError, ValueError) as exc:
                raise HardwareSpecError(f"invalid supported dtype: {value!r}") from exc
            dtypes.append(dtype)
        if len(dtypes) != len(set(dtypes)):
            raise HardwareSpecError("supported dtypes must be unique")
        object.__setattr__(self, "supported_dtypes", tuple(dtypes))

        implementations = tuple(self.supported_implementation_ids)
        object.__setattr__(self, "supported_implementation_ids", implementations)
        if any(not isinstance(value, str) or not value for value in implementations):
            raise HardwareSpecError("supported implementation IDs must be non-empty strings")
        try:
            for value in implementations:
                value.encode("ascii")
        except UnicodeEncodeError as exc:
            raise HardwareSpecError("supported implementation IDs must be ASCII") from exc

    def __eq__(self, other: object) -> bool:
        if isinstance(other, HardwareSpec):
            return (
                self.ref == other.ref
                and self.architecture == other.architecture
                and self.temporal_resources == other.temporal_resources
                and self.static_resources == other.static_resources
                and self.supported_dtypes == other.supported_dtypes
                and self.supported_implementation_ids == other.supported_implementation_ids
                and self.schema_version == other.schema_version
            )
        if isinstance(other, Mapping):
            return _json_form(self) == _json_form(other)
        return NotImplemented

    def temporal_capacity(self, resource_id: ResourceId) -> int:
        """Return a temporal capacity, rejecting static-resource IDs."""

        for resource in self.temporal_resources:
            if resource.resource_id == resource_id:
                return resource.capacity_slots
        raise HardwareSpecError(f"unknown temporal resource: {resource_id!r}")

    def static_capacity(self, resource_id: ResourceId) -> int:
        """Return a static capacity, rejecting temporal-resource IDs."""

        for resource in self.static_resources:
            if resource.resource_id == resource_id:
                return resource.capacity_units
        raise HardwareSpecError(f"unknown static resource: {resource_id!r}")


def _coerce_temporal_resource(value: object) -> TemporalResourceSpec:
    if isinstance(value, TemporalResourceSpec):
        return value
    if not isinstance(value, Mapping):
        raise HardwareSpecError("temporal resource must be a typed record")
    allowed = {"resource_id", "capacity_slots", "description", "provenance"}
    required = allowed
    _strict_mapping(value, allowed, required, "temporal resource")
    return TemporalResourceSpec(
        ResourceId(_string(value["resource_id"], "resource_id")),
        _int(value["capacity_slots"], "capacity_slots"),
        _string(value["description"], "description"),
        _coerce_provenance(value["provenance"]),
    )


def _coerce_static_resource(value: object) -> StaticResourceSpec:
    if isinstance(value, StaticResourceSpec):
        return value
    if not isinstance(value, Mapping):
        raise HardwareSpecError("static resource must be a typed record")
    allowed = {"resource_id", "capacity_units", "unit", "description", "provenance"}
    _strict_mapping(value, allowed, allowed, "static resource")
    return StaticResourceSpec(
        ResourceId(_string(value["resource_id"], "resource_id")),
        _int(value["capacity_units"], "capacity_units"),
        _coerce_enum_value(value["unit"], StaticUnit, "unit"),
        _string(value["description"], "description"),
        _coerce_provenance(value["provenance"]),
    )


def _coerce_provenance(value: object) -> FactProvenance:
    if isinstance(value, FactProvenance):
        return value
    if not isinstance(value, Mapping):
        raise HardwareSpecError("resource provenance must be an object")
    allowed = {"origin", "source", "conditions"}
    _strict_mapping(value, allowed, allowed, "resource provenance")
    return FactProvenance(
        _coerce_enum_value(value["origin"], FactOrigin, "origin"),
        _string(value["source"], "source"),
        _string(value["conditions"], "conditions"),
    )


def _strict_mapping(
    value: Mapping[object, object],
    allowed: set[str],
    required: set[str],
    label: str,
) -> None:
    keys = set(value)
    if any(not isinstance(key, str) for key in keys):
        raise HardwareSpecError(f"{label} keys must be strings")
    string_keys = {key for key in keys if isinstance(key, str)}
    unknown = sorted(string_keys - allowed)
    missing = sorted(required - string_keys)
    if unknown:
        raise HardwareSpecError(f"{label} contains unknown field(s): {', '.join(unknown)}")
    if missing:
        raise HardwareSpecError(f"{label} is missing required field(s): {', '.join(missing)}")


def _string(value: object, label: str) -> str:
    if not isinstance(value, str):
        raise HardwareSpecError(f"{label} must be a string")
    return value


def _int(value: object, label: str) -> int:
    if isinstance(value, bool) or not isinstance(value, int):
        raise HardwareSpecError(f"{label} must be an integer")
    return value


def _positive_int(value: object, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise HardwareSpecError(f"{label} must be a positive integer")


def _hardware_string(value: object, label: str) -> None:
    if not isinstance(value, str) or not value:
        raise HardwareSpecError(f"{label} must be a non-empty string")


def _hardware_identifier(value: object, label: str) -> None:
    if not isinstance(value, str):
        raise HardwareSpecError(f"{label} must be a non-empty ASCII string")
    try:
        value.encode("ascii")
    except UnicodeEncodeError as exc:
        raise HardwareSpecError(f"{label} must be a non-empty ASCII string") from exc
    _hardware_string(value, label)


def _coerce_enum(instance: object, field_name: str, enum_type: type[Enum]) -> None:
    value = getattr(instance, field_name)
    if isinstance(value, enum_type):
        return
    try:
        object.__setattr__(instance, field_name, enum_type(value))
    except (TypeError, ValueError) as exc:
        raise HardwareSpecError(f"invalid {field_name}: {value!r}") from exc


_EnumT = TypeVar("_EnumT", bound=Enum)


def _coerce_enum_value(value: object, enum_type: type[_EnumT], label: str) -> _EnumT:
    try:
        return value if isinstance(value, enum_type) else enum_type(value)
    except (TypeError, ValueError) as exc:
        raise HardwareSpecError(f"invalid {label}: {value!r}") from exc


def _unique_ids(values: tuple[object, ...], field_name: str, label: str) -> None:
    ids = tuple(str(getattr(item, field_name)) for item in values)
    if len(ids) != len(set(ids)):
        raise HardwareSpecError(f"{label} must be unique")


def _json_form(value: object) -> object:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _json_form(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_form(item) for item in value]
    if isinstance(value, FactProvenance):
        return {
            "origin": _json_form(value.origin),
            "source": value.source,
            "conditions": value.conditions,
        }
    if isinstance(value, TemporalResourceSpec):
        return {
            "resource_id": str(value.resource_id),
            "capacity_slots": value.capacity_slots,
            "description": value.description,
            "provenance": _json_form(value.provenance),
        }
    if isinstance(value, StaticResourceSpec):
        return {
            "resource_id": str(value.resource_id),
            "capacity_units": value.capacity_units,
            "unit": _json_form(value.unit),
            "description": value.description,
            "provenance": _json_form(value.provenance),
        }
    if isinstance(value, HardwareSpecRef):
        return {
            "hardware_id": value.hardware_id,
            "schema_version": value.schema_version,
            "calibration_id": value.calibration_id,
        }
    if isinstance(value, HardwareSpec):
        return {
            "schema_version": value.schema_version,
            "ref": _json_form(value.ref),
            "architecture": value.architecture,
            "temporal_resources": _json_form(value.temporal_resources),
            "static_resources": _json_form(value.static_resources),
            "supported_dtypes": _json_form(value.supported_dtypes),
            "supported_implementation_ids": _json_form(value.supported_implementation_ids),
        }
    return value


__all__ = [
    "FactOrigin",
    "FactProvenance",
    "HardwareSpec",
    "HardwareSpecRef",
    "StaticResourceSpec",
    "StaticUnit",
    "TemporalResourceSpec",
]
