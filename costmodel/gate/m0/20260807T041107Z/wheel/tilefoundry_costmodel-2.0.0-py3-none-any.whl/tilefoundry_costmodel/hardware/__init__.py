"""Hardware catalog boundary reserved for M1."""

from __future__ import annotations

from dataclasses import dataclass

from ..errors import HardwareSpecError, UnsupportedError
from ..model import HardwareSpecRef
from .model import (
    FactOrigin,
    FactProvenance,
    HardwareSpec,
    StaticResourceSpec,
    StaticUnit,
    TemporalResourceSpec,
)


@dataclass(frozen=True, slots=True)
class HardwareCatalog:
    """Explicit hardware-document catalog interface."""

    specs: tuple[HardwareSpec, ...] = ()

    def __post_init__(self) -> None:
        specs = tuple(self.specs)
        object.__setattr__(self, "specs", specs)
        if not all(isinstance(spec, HardwareSpec) for spec in specs):
            raise HardwareSpecError("hardware catalog must contain HardwareSpec records")

    def resolve(self, ref: HardwareSpecRef) -> HardwareSpec:
        for spec in self.specs:
            if spec.ref == ref:
                return spec
        raise UnsupportedError(f"hardware reference is not installed: {ref!r}")


def b200_hardware_catalog() -> HardwareCatalog:
    """Return the future B200 catalog placeholder."""

    return HardwareCatalog()


__all__ = [
    "FactOrigin",
    "FactProvenance",
    "HardwareCatalog",
    "HardwareSpec",
    "HardwareSpecRef",
    "StaticResourceSpec",
    "StaticUnit",
    "TemporalResourceSpec",
    "b200_hardware_catalog",
]
