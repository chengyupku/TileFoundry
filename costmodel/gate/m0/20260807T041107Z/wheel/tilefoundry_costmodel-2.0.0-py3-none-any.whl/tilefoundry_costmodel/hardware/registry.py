"""Hardware registry boundary reserved for M1."""

from . import HardwareCatalog, b200_hardware_catalog

__all__ = ["HardwareCatalog", "b200_hardware_catalog"]
