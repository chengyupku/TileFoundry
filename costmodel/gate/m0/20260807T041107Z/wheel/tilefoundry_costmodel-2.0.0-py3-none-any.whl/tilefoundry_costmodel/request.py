"""Immutable request-side records for the version 2 public API."""

from __future__ import annotations

import json
import math
from dataclasses import dataclass, field
from enum import Enum

from .constants import PROGRAM_SCHEMA_VERSION, REQUEST_SCHEMA_VERSION
from .errors import InvalidRequestError
from .model import (
    FlashAttentionSpec,
    GemmSpec,
    GqaDecodeSpec,
    HardwareSpecRef,
    MlpSpec,
    WorkloadSpec,
    validate_identifier,
)
from .program import TileProgram


class WarpRole(str, Enum):
    """Name one initial B200 warp role."""

    TMA_PRODUCER = "tma_producer"
    TENSOR_CONSUMER = "tensor_consumer"
    CUDA_EPILOGUE = "cuda_epilogue"


@dataclass(frozen=True, slots=True)
class WarpRoleAssignment:
    role: WarpRole
    warp_ids: tuple[int, ...]

    def __post_init__(self) -> None:
        _coerce_enum(self, "role", WarpRole)
        ids = tuple(self.warp_ids)
        object.__setattr__(self, "warp_ids", ids)
        if len(ids) != len(set(ids)) or any(
            isinstance(value, bool) or not isinstance(value, int) or value < 0 for value in ids
        ):
            raise InvalidRequestError("warp IDs must be unique non-negative integers")


@dataclass(frozen=True, slots=True)
class WarpConfig:
    config_id: str
    total_warps: int
    roles: tuple[WarpRoleAssignment, ...]

    def __post_init__(self) -> None:
        validate_identifier(self.config_id, label="warp config ID")
        if (
            isinstance(self.total_warps, bool)
            or not isinstance(self.total_warps, int)
            or self.total_warps <= 0
        ):
            raise InvalidRequestError("total_warps must be positive")
        roles = tuple(self.roles)
        object.__setattr__(self, "roles", roles)
        if not all(isinstance(assignment, WarpRoleAssignment) for assignment in roles):
            raise InvalidRequestError("roles must contain WarpRoleAssignment records")
        role_ids: dict[WarpRole, set[int]] = {}
        all_ids: list[int] = []
        for assignment in roles:
            if assignment.role in role_ids:
                raise InvalidRequestError("warp roles must be unique")
            assigned = role_ids.setdefault(assignment.role, set())
            assigned.update(assignment.warp_ids)
            all_ids.extend(assignment.warp_ids)
        if any(warp_id >= self.total_warps for warp_id in all_ids):
            raise InvalidRequestError("warp IDs must be less than total_warps")


@dataclass(frozen=True, slots=True)
class SearchSpace:
    implementation_ids: tuple[str, ...]
    warp_configs: tuple[WarpConfig, ...]
    pipeline_depths: tuple[int, ...]
    layout_variant_ids: tuple[str, ...] = ()
    max_candidates: int = 10_000

    def __post_init__(self) -> None:
        implementations = tuple(self.implementation_ids)
        warps = tuple(self.warp_configs)
        depths = tuple(self.pipeline_depths)
        layouts = tuple(self.layout_variant_ids)
        if not layouts:
            layouts = ("default",)
        object.__setattr__(self, "implementation_ids", implementations)
        object.__setattr__(self, "warp_configs", warps)
        object.__setattr__(self, "pipeline_depths", depths)
        object.__setattr__(self, "layout_variant_ids", layouts)
        if not implementations or any(
            not isinstance(value, str) or not value for value in implementations
        ):
            raise InvalidRequestError("implementation_ids must be non-empty strings")
        for value in implementations:
            validate_identifier(value, label="implementation_id")
        if not warps:
            raise InvalidRequestError("warp_configs must not be empty")
        if not all(isinstance(value, WarpConfig) for value in warps):
            raise InvalidRequestError("warp_configs must contain WarpConfig records")
        if (
            not depths
            or len(depths) != len(set(depths))
            or any(
                isinstance(value, bool) or not isinstance(value, int) or not 1 <= value <= 8
                for value in depths
            )
        ):
            raise InvalidRequestError("pipeline_depths must be unique integers in 1..8")
        if any(not isinstance(value, str) or not value for value in layouts):
            raise InvalidRequestError("layout_variant_ids must contain non-empty strings")
        for value in layouts:
            validate_identifier(value, label="layout_variant_id")
        if (
            isinstance(self.max_candidates, bool)
            or not isinstance(self.max_candidates, int)
            or self.max_candidates <= 0
        ):
            raise InvalidRequestError("max_candidates must be positive")


class ProfileMode(str, Enum):
    """Control behavior on an exact profile miss."""

    REQUIRE = "require"
    JIT_ON_MISS = "jit_on_miss"


class TimingStatistic(str, Enum):
    """Select a measured timing aggregate."""

    P50 = "p50"
    P90 = "p90"


@dataclass(frozen=True, slots=True)
class ProfileSnapshotRef:
    snapshot_id: str
    revision: int

    def __post_init__(self) -> None:
        validate_identifier(self.snapshot_id, label="snapshot_id")
        if (
            isinstance(self.revision, bool)
            or not isinstance(self.revision, int)
            or self.revision <= 0
        ):
            raise InvalidRequestError("snapshot revision must be positive")


@dataclass(frozen=True, slots=True)
class ProfileSelection:
    snapshot: ProfileSnapshotRef
    mode: ProfileMode = ProfileMode.REQUIRE
    timing_statistic: TimingStatistic = TimingStatistic.P50

    def __post_init__(self) -> None:
        if not isinstance(self.snapshot, ProfileSnapshotRef):
            raise InvalidRequestError("snapshot must be ProfileSnapshotRef")
        _coerce_enum(self, "mode", ProfileMode)
        _coerce_enum(self, "timing_statistic", TimingStatistic)


@dataclass(frozen=True, slots=True)
class SolverOptions:
    """Configure candidate search and numeric solving.

    The fields are intentionally solver-neutral.  M0 does not import or
    configure OR-Tools; the options are frozen so a later solver can consume a
    replayable value without sharing mutable backend state.
    """

    candidate_timeout_s: float | None = 30.0
    search_timeout_s: float | None = None
    time_resolution_ps: int = 10
    ortools_workers: int = 1
    candidate_workers: int = 1
    random_seed: int = 0
    finite_unroll_limit: int = 64
    stop_after_first_solution: bool = False
    deterministic: bool = True

    def __post_init__(self) -> None:
        for name in ("candidate_timeout_s", "search_timeout_s"):
            value = getattr(self, name)
            if value is not None and (
                isinstance(value, bool)
                or not isinstance(value, (int, float))
                or not math.isfinite(float(value))
                or value <= 0
            ):
                raise InvalidRequestError(f"{name} must be positive or None")
        for name in (
            "time_resolution_ps",
            "ortools_workers",
            "candidate_workers",
            "finite_unroll_limit",
        ):
            value = getattr(self, name)
            if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
                raise InvalidRequestError(f"{name} must be a positive integer")
        if isinstance(self.random_seed, bool) or not isinstance(self.random_seed, int):
            raise InvalidRequestError("random_seed must be an integer")
        if not isinstance(self.stop_after_first_solution, bool) or not isinstance(
            self.deterministic, bool
        ):
            raise InvalidRequestError("solver boolean options must be boolean")
        if self.deterministic and (
            self.ortools_workers != 1
            or self.candidate_workers != 1
            or self.stop_after_first_solution
        ):
            raise InvalidRequestError("deterministic mode requires one worker and no early stop")


@dataclass(frozen=True, slots=True)
class CostModelRequest:
    """Describe one finite version 2 cost-model search."""

    schema_version: int
    request_id: str
    workload: WorkloadSpec
    programs: tuple[TileProgram, ...]
    hardware: HardwareSpecRef
    search_space: SearchSpace
    profiles: ProfileSelection
    solver: SolverOptions = field(default_factory=SolverOptions)

    def __post_init__(self) -> None:
        if (
            isinstance(self.schema_version, bool)
            or not isinstance(self.schema_version, int)
            or self.schema_version != REQUEST_SCHEMA_VERSION
        ):
            raise InvalidRequestError(
                f"unsupported request schema version: {self.schema_version!r}"
            )
        validate_identifier(self.request_id, label="request_id")
        programs = tuple(self.programs)
        object.__setattr__(self, "programs", programs)
        if not programs:
            raise InvalidRequestError("request must contain at least one program")
        if not isinstance(self.workload, (GemmSpec, GqaDecodeSpec, FlashAttentionSpec, MlpSpec)):
            raise InvalidRequestError("workload must be a typed workload record")
        if not isinstance(self.hardware, HardwareSpecRef):
            raise InvalidRequestError("hardware must be HardwareSpecRef")
        if not isinstance(self.search_space, SearchSpace):
            raise InvalidRequestError("search_space must be SearchSpace")
        if not isinstance(self.profiles, ProfileSelection):
            raise InvalidRequestError("profiles must be ProfileSelection")
        if not all(isinstance(program, TileProgram) for program in programs):
            raise InvalidRequestError("programs must contain TileProgram records")
        ids = tuple(str(program.program_id) for program in programs)
        if len(ids) != len(set(ids)):
            raise InvalidRequestError("program IDs must be unique")
        if any(program.schema_version != PROGRAM_SCHEMA_VERSION for program in programs):
            raise InvalidRequestError("request contains an unsupported program schema version")
        try:
            canonical_programs = tuple(_canonical_program_key(program) for program in programs)
        except (InvalidRequestError, TypeError, ValueError) as exc:
            raise InvalidRequestError("request programs must have a canonical JSON form") from exc
        if len(canonical_programs) != len(set(canonical_programs)):
            raise InvalidRequestError("request contains duplicate canonical programs")
        if hasattr(self.workload, "kind") and any(
            program.workload_kind != self.workload.kind for program in programs
        ):
            raise InvalidRequestError("program workload kinds must match request workload")
        if not isinstance(self.solver, SolverOptions):
            raise InvalidRequestError("solver must be SolverOptions")

    def to_json(self) -> str:
        from ._serialization import request_to_json

        return request_to_json(self)

    @classmethod
    def from_json(cls, text: str) -> "CostModelRequest":
        from ._serialization import request_from_json

        return request_from_json(text)


def _coerce_enum(instance: object, field_name: str, enum_type: type[Enum]) -> None:
    value = getattr(instance, field_name)
    if isinstance(value, enum_type):
        return
    try:
        object.__setattr__(instance, field_name, enum_type(value))
    except (TypeError, ValueError) as exc:
        raise InvalidRequestError(f"invalid {field_name}") from exc


def _canonical_program_key(program: TileProgram) -> str:
    """Return a variant identity that excludes only the program-local ID."""

    from ._serialization import canonical_json, program_to_json

    payload = json.loads(program_to_json(program))
    if not isinstance(payload, dict):  # pragma: no cover - guarded by the codec
        raise TypeError("program JSON must be an object")
    payload.pop("program_id", None)
    return canonical_json(payload)


__all__ = [
    "CostModelRequest",
    "ProfileMode",
    "ProfileSelection",
    "ProfileSnapshotRef",
    "SearchSpace",
    "SolverOptions",
    "TimingStatistic",
    "WarpConfig",
    "WarpRole",
    "WarpRoleAssignment",
]
