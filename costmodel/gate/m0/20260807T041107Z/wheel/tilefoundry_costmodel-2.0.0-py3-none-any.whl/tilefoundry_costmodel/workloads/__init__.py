"""Optional workload frontend boundary reserved for M1."""

from __future__ import annotations

from dataclasses import dataclass

from ..errors import UnsupportedError
from ..model import WorkloadKind


@dataclass(frozen=True, slots=True)
class WorkloadFrontendCatalog:
    frontends: tuple[object, ...] = ()

    def frontend_for(self, kind: WorkloadKind) -> object:
        for frontend in self.frontends:
            if getattr(frontend, "workload_kind", None) == kind:
                return frontend
        raise UnsupportedError(f"no frontend is installed for {kind.value}")


def builtin_workload_frontends() -> WorkloadFrontendCatalog:
    """Return an empty frontend catalog until M1."""

    return WorkloadFrontendCatalog()


__all__ = ["WorkloadFrontendCatalog", "builtin_workload_frontends"]
