"""Operation implementation catalogs and lowering protocols."""

from __future__ import annotations

from .base import (
    CudaBenchmarkProvider,
    LoweredTileOp,
    LoweringContext,
    TileOpImplementation,
    TileOpLowering,
)
from .registry import ImplementationCatalog
from .synthetic import (
    SyntheticBenchmarkProvider,
    SyntheticLowering,
    synthetic_implementation_catalog,
)


def b200_implementation_catalog() -> ImplementationCatalog:
    """Return the real B200 catalog boundary (providers arrive in M3/M5)."""

    return ImplementationCatalog(())


__all__ = [
    "CudaBenchmarkProvider",
    "ImplementationCatalog",
    "LoweredTileOp",
    "LoweringContext",
    "SyntheticBenchmarkProvider",
    "SyntheticLowering",
    "TileOpImplementation",
    "TileOpLowering",
    "b200_implementation_catalog",
    "synthetic_implementation_catalog",
]
