"""Pure benchmark/provider protocols used by M2.

The records describe a future CUDA benchmark, but importing this module never
imports CUDA Python, NVRTC, a driver, or a compiler.  Actual execution is an
M3 concern.
"""

from __future__ import annotations

import math
from dataclasses import dataclass
from enum import Enum
from typing import Protocol, TypeAlias

from ..errors import ProfileRunError, ProfileStoreError
from ..hardware.model import HardwareSpec, HardwareSpecRef
from ..model import TimingMetric, validate_identifier
from ..tileop import (
    BenchmarkFingerprint,
    TileOpProfileKey,
    TileOpProfileQuery,
)


def _id(value: object, label: str) -> None:
    if not isinstance(value, str):
        raise ProfileStoreError(f"{label} must be a non-empty ASCII string")
    try:
        validate_identifier(value, label=label)
    except Exception as exc:
        raise ProfileStoreError(str(exc)) from exc


def _positive(value: object, label: str, error: type[Exception] = ProfileStoreError) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise error(f"{label} must be a positive integer")


class CudaBufferRole(str, Enum):
    INPUT = "input"
    OUTPUT = "output"
    INOUT = "inout"


class CudaBufferInit(str, Enum):
    ZERO = "zero"
    RANDOM_UNIFORM = "random_uniform"
    SEQUENCE = "sequence"


class CudaScalarDType(str, Enum):
    I32 = "i32"
    I64 = "i64"
    U32 = "u32"
    U64 = "u64"
    F32 = "f32"
    F64 = "f64"


@dataclass(frozen=True, slots=True)
class CudaBufferArgument:
    name: str
    nbytes: int
    role: CudaBufferRole
    initialization: CudaBufferInit
    seed: int = 0

    def __post_init__(self) -> None:
        _id(self.name, "buffer argument name")
        _positive(self.nbytes, "buffer argument nbytes")
        _coerce_enum(self, "role", CudaBufferRole)
        _coerce_enum(self, "initialization", CudaBufferInit)
        if isinstance(self.seed, bool) or not isinstance(self.seed, int) or self.seed < 0:
            raise ProfileStoreError("buffer argument seed must be non-negative")


@dataclass(frozen=True, slots=True)
class CudaScalarArgument:
    name: str
    dtype: CudaScalarDType
    value: int | float

    def __post_init__(self) -> None:
        _id(self.name, "scalar argument name")
        _coerce_enum(self, "dtype", CudaScalarDType)
        if isinstance(self.value, bool) or not isinstance(self.value, (int, float)):
            raise ProfileStoreError("scalar argument value must be numeric")
        if isinstance(self.value, float) and not math.isfinite(self.value):
            raise ProfileStoreError("scalar argument value must be finite")


CudaArgument: TypeAlias = CudaBufferArgument | CudaScalarArgument


@dataclass(frozen=True, slots=True)
class CudaLaunchSpec:
    grid: tuple[int, int, int]
    block: tuple[int, int, int]
    dynamic_smem_bytes: int

    def __post_init__(self) -> None:
        for value, label in ((self.grid, "grid"), (self.block, "block")):
            if not isinstance(value, (tuple, list)) or len(value) != 3:
                raise ProfileStoreError(f"{label} must contain three dimensions")
            if any(
                isinstance(item, bool) or not isinstance(item, int) or item <= 0 for item in value
            ):
                raise ProfileStoreError(f"{label} dimensions must be positive integers")
            object.__setattr__(self, label, tuple(value))
        if (
            isinstance(self.dynamic_smem_bytes, bool)
            or not isinstance(self.dynamic_smem_bytes, int)
            or self.dynamic_smem_bytes < 0
        ):
            raise ProfileStoreError("dynamic_smem_bytes must be non-negative")


@dataclass(frozen=True, slots=True)
class CudaBenchmarkCase:
    metric: TimingMetric
    kernel_name: str
    launch: CudaLaunchSpec
    arguments: tuple[CudaArgument, ...]
    repetition_argument_name: str

    def __post_init__(self) -> None:
        _coerce_enum(self, "metric", TimingMetric)
        _id(self.kernel_name, "kernel_name")
        if type(self.launch) is not CudaLaunchSpec:
            raise ProfileStoreError("benchmark launch must be CudaLaunchSpec")
        if not isinstance(self.arguments, (tuple, list)):
            raise ProfileStoreError("benchmark arguments must be a sequence")
        arguments = tuple(self.arguments)
        if not all(type(item) in (CudaBufferArgument, CudaScalarArgument) for item in arguments):
            raise ProfileStoreError("benchmark arguments must be typed")
        names = tuple(item.name for item in arguments)
        if len(names) != len(set(names)):
            raise ProfileStoreError("benchmark argument names must be unique")
        _id(self.repetition_argument_name, "repetition argument name")
        if self.repetition_argument_name not in names:
            raise ProfileStoreError("repetition argument must be present")
        repetition = next(item for item in arguments if item.name == self.repetition_argument_name)
        if not isinstance(repetition, CudaScalarArgument) or repetition.dtype not in (
            CudaScalarDType.I32,
            CudaScalarDType.I64,
            CudaScalarDType.U32,
            CudaScalarDType.U64,
        ):
            raise ProfileStoreError("repetition argument must be an integer scalar")
        object.__setattr__(self, "arguments", arguments)


@dataclass(frozen=True, slots=True)
class CudaBenchmark:
    key: TileOpProfileKey
    source_utf8: str
    compile_options: tuple[str, ...]
    latency_case: CudaBenchmarkCase
    initiation_interval_case: CudaBenchmarkCase | None

    def __post_init__(self) -> None:
        if type(self.key) is not TileOpProfileKey:
            raise ProfileStoreError("benchmark key must be TileOpProfileKey")
        if not isinstance(self.source_utf8, str) or not self.source_utf8:
            raise ProfileStoreError("benchmark source must be non-empty text")
        if not isinstance(self.compile_options, (tuple, list)):
            raise ProfileStoreError("compile_options must be a sequence")
        options = tuple(self.compile_options)
        if not all(isinstance(item, str) and item for item in options):
            raise ProfileStoreError("compile options must be non-empty strings")
        if len(options) != len(set(options)) or options != tuple(sorted(options)):
            raise ProfileStoreError("compile options must be unique and sorted")
        if type(self.latency_case) is not CudaBenchmarkCase:
            raise ProfileStoreError("latency_case must be CudaBenchmarkCase")
        if self.latency_case.metric is not TimingMetric.LATENCY:
            raise ProfileStoreError("latency_case must use latency metric")
        if self.latency_case.launch.grid != (1, 1, 1):
            raise ProfileStoreError("initial benchmark grid must equal (1, 1, 1)")
        if self.initiation_interval_case is not None:
            if type(self.initiation_interval_case) is not CudaBenchmarkCase:
                raise ProfileStoreError("initiation_interval_case must be CudaBenchmarkCase")
            if self.initiation_interval_case.metric is not TimingMetric.INITIATION_INTERVAL:
                raise ProfileStoreError("initiation case must use initiation_interval metric")
            if self.initiation_interval_case.launch.grid != (1, 1, 1):
                raise ProfileStoreError("initial benchmark grid must equal (1, 1, 1)")
        object.__setattr__(self, "compile_options", options)


@dataclass(frozen=True, slots=True)
class NamedBufferOutput:
    metric: TimingMetric
    name: str
    data: bytes

    def __post_init__(self) -> None:
        _coerce_enum(self, "metric", TimingMetric)
        _id(self.name, "output name")
        if not isinstance(self.data, bytes):
            raise ProfileRunError("benchmark output data must be bytes")


@dataclass(frozen=True, slots=True)
class ProfileEnvironment:
    environment_id: str
    device_uuid: str
    hardware: HardwareSpecRef
    cuda_arch: str
    driver_version: str
    runtime_version: str
    nvrtc_version: str
    device_clock_khz: int | None
    memory_clock_khz: int | None
    power_limit_mw: int | None

    def __post_init__(self) -> None:
        for value, label in (
            (self.environment_id, "environment_id"),
            (self.device_uuid, "device_uuid"),
            (self.cuda_arch, "cuda_arch"),
            (self.driver_version, "driver_version"),
            (self.runtime_version, "runtime_version"),
            (self.nvrtc_version, "nvrtc_version"),
        ):
            _id(value, label)
        if type(self.hardware) is not HardwareSpecRef:
            raise ProfileStoreError("profile environment hardware must be HardwareSpecRef")
        for quantity, label in (
            (self.device_clock_khz, "device_clock_khz"),
            (self.memory_clock_khz, "memory_clock_khz"),
            (self.power_limit_mw, "power_limit_mw"),
        ):
            if quantity is not None:
                _positive(quantity, label)


@dataclass(frozen=True, slots=True)
class ProfileRun:
    environment: ProfileEnvironment
    latency_samples_ps: tuple[int, ...]
    initiation_interval_samples_ps: tuple[int, ...]
    latency_repetitions_per_sample: int
    initiation_interval_repetitions_per_sample: int | None
    outputs: tuple[NamedBufferOutput, ...]

    def __post_init__(self) -> None:
        if type(self.environment) is not ProfileEnvironment:
            raise ProfileRunError("profile run environment must be ProfileEnvironment")
        for values, label in (
            (self.latency_samples_ps, "latency_samples_ps"),
            (self.initiation_interval_samples_ps, "initiation_interval_samples_ps"),
        ):
            if not isinstance(values, (tuple, list)):
                raise ProfileRunError(f"{label} must be a sequence")
            if any(
                isinstance(item, bool) or not isinstance(item, int) or item <= 0 for item in values
            ):
                raise ProfileRunError(f"{label} must contain positive integers")
            object.__setattr__(self, label, tuple(values))
        _positive(
            self.latency_repetitions_per_sample, "latency_repetitions_per_sample", ProfileRunError
        )
        if self.initiation_interval_repetitions_per_sample is not None:
            _positive(
                self.initiation_interval_repetitions_per_sample,
                "initiation_interval_repetitions_per_sample",
                ProfileRunError,
            )
        if not isinstance(self.outputs, (tuple, list)):
            raise ProfileRunError("profile outputs must be a sequence")
        outputs = tuple(self.outputs)
        if not all(type(item) is NamedBufferOutput for item in outputs):
            raise ProfileRunError("profile outputs must contain NamedBufferOutput records")
        object.__setattr__(self, "outputs", outputs)


@dataclass(frozen=True, slots=True)
class MeasurementPolicy:
    """Runner-neutral measurement controls reserved for M3 execution."""

    warmup_runs: int = 20
    sample_count: int = 100
    target_sample_ns: int = 100_000
    max_repetitions_per_sample: int = 1_000_000
    max_relative_iqr_ppm: int = 50_000
    retain_raw_samples: bool = False

    def __post_init__(self) -> None:
        for value, label in (
            (self.warmup_runs, "warmup_runs"),
            (self.sample_count, "sample_count"),
            (self.target_sample_ns, "target_sample_ns"),
            (self.max_repetitions_per_sample, "max_repetitions_per_sample"),
            (self.max_relative_iqr_ppm, "max_relative_iqr_ppm"),
        ):
            if isinstance(value, bool) or not isinstance(value, int) or value < 0:
                raise ProfileStoreError(f"{label} must be non-negative")
        if (
            self.sample_count == 0
            or self.target_sample_ns == 0
            or self.max_repetitions_per_sample == 0
        ):
            raise ProfileStoreError(
                "sample_count, target_sample_ns and repetition cap must be positive"
            )
        if not isinstance(self.retain_raw_samples, bool):
            raise ProfileStoreError("retain_raw_samples must be boolean")


class ProfileRunner(Protocol):
    def run(
        self,
        benchmark: CudaBenchmark,
        *,
        hardware: HardwareSpec,
        policy: MeasurementPolicy,
    ) -> ProfileRun: ...


class CudaBenchmarkProvider(Protocol):
    """Full provider protocol; execution remains an M3 implementation."""

    @property
    def provider_id(self) -> str: ...

    @property
    def provider_version(self) -> str: ...

    def supports(self, query: TileOpProfileQuery) -> bool: ...

    def fingerprint(
        self, query: TileOpProfileQuery, hardware: HardwareSpec
    ) -> BenchmarkFingerprint: ...

    def materialize(self, key: TileOpProfileKey, hardware: HardwareSpec) -> CudaBenchmark: ...

    def validate(self, benchmark: CudaBenchmark, run: ProfileRun) -> None: ...


FullCudaBenchmarkProvider = CudaBenchmarkProvider


def _coerce_enum(instance: object, field_name: str, enum_type: type[Enum]) -> None:
    value = getattr(instance, field_name)
    if isinstance(value, enum_type):
        return
    try:
        object.__setattr__(instance, field_name, enum_type(value))
    except (TypeError, ValueError) as exc:
        raise ProfileStoreError(f"invalid {field_name}: {value!r}") from exc


__all__ = [
    "CudaArgument",
    "CudaBenchmark",
    "CudaBenchmarkCase",
    "CudaBufferArgument",
    "CudaBufferInit",
    "CudaBufferRole",
    "CudaBenchmarkProvider",
    "CudaLaunchSpec",
    "CudaScalarArgument",
    "CudaScalarDType",
    "FullCudaBenchmarkProvider",
    "NamedBufferOutput",
    "MeasurementPolicy",
    "ProfileEnvironment",
    "ProfileRun",
    "ProfileRunner",
]
