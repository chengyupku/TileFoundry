"""Immutable profile identity and exported snapshot records.

M2 owns canonical typed profile keys.  Measurement environments and store
behavior remain the M3 boundary and retain their strict immutable JSON shape.
"""

from __future__ import annotations

from collections.abc import Mapping
from dataclasses import dataclass, fields, is_dataclass
from enum import Enum

from .._immutable import FrozenJsonObject
from ..constants import PROFILE_SCHEMA_VERSION
from ..errors import InvalidRequestError, ProfileStoreError
from ..hardware.model import HardwareSpec
from ..model import MeasurementId, validate_identifier
from ..tileop import (
    BenchmarkFingerprint,
    CanonicalAttribute,
    ProfileRequirement,
    TileOpProfileKey,
    TileOpProfileQuery,
    TileOpSignature,
    profile_key_from_json,
    profile_key_to_json,
    profile_query_canonical_json,
    tile_op_signature,
)


class MeasurementOrigin(str, Enum):
    """Name an accepted timing origin."""

    MEASURED = "measured"


@dataclass(frozen=True, slots=True)
class ProfileMeasurement:
    """Carry one validated, recursively immutable snapshot measurement."""

    measurement_id: MeasurementId
    key: TileOpProfileKey
    environment: FrozenJsonObject
    origin: MeasurementOrigin
    latency_p50_ps: int
    latency_p90_ps: int
    initiation_interval_p50_ps: int | None
    initiation_interval_p90_ps: int | None
    warmup_runs: int
    sample_count: int
    latency_repetitions_per_sample: int
    initiation_interval_repetitions_per_sample: int | None
    target_sample_ns: int
    relative_iqr_ppm: int
    raw_samples_retained: bool
    raw_latency_samples_ps: tuple[int, ...]
    raw_initiation_interval_samples_ps: tuple[int, ...]
    measured_at_utc: str

    def __post_init__(self) -> None:
        _profile_identifier(self.measurement_id, "measurement_id")
        if type(self.key) is not TileOpProfileKey:
            raise ProfileStoreError("measurement key must be TileOpProfileKey")
        if not isinstance(self.environment, FrozenJsonObject):
            raise ProfileStoreError("measurement environment must be immutable")
        _require_keys(
            self.environment,
            {
                "environment_id",
                "device_uuid",
                "hardware",
                "cuda_arch",
                "driver_version",
                "runtime_version",
                "nvrtc_version",
                "device_clock_khz",
                "memory_clock_khz",
                "power_limit_mw",
            },
            "profile environment",
        )
        if not isinstance(self.origin, MeasurementOrigin):
            try:
                object.__setattr__(self, "origin", MeasurementOrigin(self.origin))
            except (TypeError, ValueError) as exc:
                raise ProfileStoreError(f"invalid measurement origin: {self.origin!r}") from exc

        _positive_int(self.latency_p50_ps, "latency_p50_ps")
        _positive_int(self.latency_p90_ps, "latency_p90_ps")
        if self.latency_p90_ps < self.latency_p50_ps:
            raise ProfileStoreError("latency_p90_ps must be at least latency_p50_ps")
        _optional_positive_int(self.initiation_interval_p50_ps, "initiation_interval_p50_ps")
        _optional_positive_int(self.initiation_interval_p90_ps, "initiation_interval_p90_ps")
        if (self.initiation_interval_p50_ps is None) != (self.initiation_interval_p90_ps is None):
            raise ProfileStoreError(
                "initiation-interval p50 and p90 must both be present or absent"
            )
        if (
            self.initiation_interval_p50_ps is not None
            and self.initiation_interval_p90_ps is not None
            and self.initiation_interval_p90_ps < self.initiation_interval_p50_ps
        ):
            raise ProfileStoreError(
                "initiation_interval_p90_ps must be at least initiation_interval_p50_ps"
            )

        _non_negative_int(self.warmup_runs, "warmup_runs")
        _positive_int(self.sample_count, "sample_count")
        _positive_int(
            self.latency_repetitions_per_sample,
            "latency_repetitions_per_sample",
        )
        _optional_positive_int(
            self.initiation_interval_repetitions_per_sample,
            "initiation_interval_repetitions_per_sample",
        )
        if (self.initiation_interval_p50_ps is None) != (
            self.initiation_interval_repetitions_per_sample is None
        ):
            raise ProfileStoreError(
                "initiation-interval timing and repetitions must both be present or absent"
            )
        _positive_int(self.target_sample_ns, "target_sample_ns")
        _non_negative_int(self.relative_iqr_ppm, "relative_iqr_ppm")
        if not isinstance(self.raw_samples_retained, bool):
            raise ProfileStoreError("raw_samples_retained must be boolean")

        latency_samples = tuple(self.raw_latency_samples_ps)
        interval_samples = tuple(self.raw_initiation_interval_samples_ps)
        object.__setattr__(self, "raw_latency_samples_ps", latency_samples)
        object.__setattr__(self, "raw_initiation_interval_samples_ps", interval_samples)
        for value in (*latency_samples, *interval_samples):
            _positive_int(value, "raw sample")
        if not self.raw_samples_retained and (latency_samples or interval_samples):
            raise ProfileStoreError("raw samples must be empty when not retained")
        if self.raw_samples_retained:
            if len(latency_samples) != self.sample_count:
                raise ProfileStoreError("raw latency samples must match sample_count")
            expected_interval_count = (
                0 if self.initiation_interval_p50_ps is None else self.sample_count
            )
            if len(interval_samples) != expected_interval_count:
                raise ProfileStoreError(
                    "raw initiation-interval samples must match the measured metric"
                )
        if not isinstance(self.measured_at_utc, str) or not self.measured_at_utc:
            raise ProfileStoreError("measured_at_utc must be a non-empty string")

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ProfileMeasurement):
            return _json_form(self) == _json_form(other)
        if isinstance(other, Mapping):
            return _json_form(self) == _json_form(other)
        return NotImplemented


@dataclass(frozen=True, slots=True)
class ProfileSnapshot:
    """Carry one strict immutable profile-snapshot-v1 document."""

    schema_version: int
    snapshot_id: str
    revision: int
    hardware: HardwareSpec
    measurements: tuple[ProfileMeasurement, ...]

    def __post_init__(self) -> None:
        if (
            isinstance(self.schema_version, bool)
            or not isinstance(self.schema_version, int)
            or self.schema_version != PROFILE_SCHEMA_VERSION
        ):
            raise ProfileStoreError(
                f"unsupported profile snapshot schema version: {self.schema_version!r}"
            )
        _profile_identifier(self.snapshot_id, "snapshot_id")
        _positive_int(self.revision, "revision")
        if not isinstance(self.hardware, HardwareSpec):
            raise ProfileStoreError("snapshot hardware must be HardwareSpec")
        measurements = tuple(self.measurements)
        object.__setattr__(self, "measurements", measurements)
        if not all(isinstance(item, ProfileMeasurement) for item in measurements):
            raise ProfileStoreError("measurements must contain ProfileMeasurement records")
        measurement_ids = tuple(item.measurement_id for item in measurements)
        if len(measurement_ids) != len(set(measurement_ids)):
            raise ProfileStoreError("measurement IDs must be unique")
        expected_hardware = {
            "hardware_id": self.hardware.ref.hardware_id,
            "schema_version": self.hardware.ref.schema_version,
            "calibration_id": self.hardware.ref.calibration_id,
        }
        for measurement in measurements:
            if measurement.environment["hardware"] != expected_hardware:
                raise ProfileStoreError("measurement environment hardware does not match snapshot")
            if measurement.key.query.hardware != self.hardware.ref:
                raise ProfileStoreError("profile key hardware does not match snapshot")

    def __eq__(self, other: object) -> bool:
        if isinstance(other, ProfileSnapshot):
            return _json_form(self) == _json_form(other)
        if isinstance(other, Mapping):
            return _json_form(self) == _json_form(other)
        return NotImplemented


# Contract-facing name retained for the measurement record implemented in M3.
TileOpMeasurement = ProfileMeasurement


def _profile_identifier(value: object, label: str) -> None:
    try:
        validate_identifier(value, label=label)  # type: ignore[arg-type]
    except InvalidRequestError as exc:
        raise ProfileStoreError(str(exc)) from exc


def _positive_int(value: object, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value <= 0:
        raise ProfileStoreError(f"{label} must be a positive integer")


def _optional_positive_int(value: object, label: str) -> None:
    if value is not None:
        _positive_int(value, label)


def _non_negative_int(value: object, label: str) -> None:
    if isinstance(value, bool) or not isinstance(value, int) or value < 0:
        raise ProfileStoreError(f"{label} must be a non-negative integer")


def _require_keys(value: FrozenJsonObject, required: set[str], label: str) -> None:
    if set(value) != required:
        raise ProfileStoreError(f"{label} has an invalid field set")


def _json_form(value: object) -> object:
    if isinstance(value, Enum):
        return value.value
    if isinstance(value, Mapping):
        return {str(key): _json_form(item) for key, item in value.items()}
    if isinstance(value, (tuple, list)):
        return [_json_form(item) for item in value]
    if isinstance(value, ProfileMeasurement):
        return {
            "measurement_id": str(value.measurement_id),
            "key": _json_form(value.key),
            "environment": _json_form(value.environment),
            "origin": _json_form(value.origin),
            "latency_p50_ps": value.latency_p50_ps,
            "latency_p90_ps": value.latency_p90_ps,
            "initiation_interval_p50_ps": value.initiation_interval_p50_ps,
            "initiation_interval_p90_ps": value.initiation_interval_p90_ps,
            "warmup_runs": value.warmup_runs,
            "sample_count": value.sample_count,
            "latency_repetitions_per_sample": value.latency_repetitions_per_sample,
            "initiation_interval_repetitions_per_sample": value.initiation_interval_repetitions_per_sample,
            "target_sample_ns": value.target_sample_ns,
            "relative_iqr_ppm": value.relative_iqr_ppm,
            "raw_samples_retained": value.raw_samples_retained,
            "raw_latency_samples_ps": _json_form(value.raw_latency_samples_ps),
            "raw_initiation_interval_samples_ps": _json_form(
                value.raw_initiation_interval_samples_ps
            ),
            "measured_at_utc": value.measured_at_utc,
        }
    if isinstance(value, ProfileSnapshot):
        return {
            "schema_version": value.schema_version,
            "snapshot_id": value.snapshot_id,
            "revision": value.revision,
            "hardware": _json_form(value.hardware),
            "measurements": _json_form(value.measurements),
        }
    # HardwareSpec supplies a mapping-compatible normalized representation via
    # its equality helper; this fallback is only used for nested scalar values.
    if isinstance(value, HardwareSpec):
        return {
            "schema_version": value.schema_version,
            "ref": {
                "hardware_id": value.ref.hardware_id,
                "schema_version": value.ref.schema_version,
                "calibration_id": value.ref.calibration_id,
            },
            "architecture": value.architecture,
            "temporal_resources": _json_form(value.temporal_resources),
            "static_resources": _json_form(value.static_resources),
            "supported_dtypes": _json_form(value.supported_dtypes),
            "supported_implementation_ids": _json_form(value.supported_implementation_ids),
        }
    if is_dataclass(value):
        return {field.name: _json_form(getattr(value, field.name)) for field in fields(value)}
    return value


__all__ = [
    "BenchmarkFingerprint",
    "CanonicalAttribute",
    "MeasurementOrigin",
    "ProfileRequirement",
    "ProfileMeasurement",
    "ProfileSnapshot",
    "TileOpMeasurement",
    "TileOpProfileKey",
    "TileOpProfileQuery",
    "TileOpSignature",
    "profile_key_from_json",
    "profile_key_to_json",
    "profile_query_canonical_json",
    "tile_op_signature",
]
