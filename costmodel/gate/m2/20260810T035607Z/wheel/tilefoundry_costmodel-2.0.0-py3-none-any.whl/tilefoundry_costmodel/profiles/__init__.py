"""Profile-store and runner boundary types.

SQLite persistence and CUDA measurement are intentionally deferred to M3. The
types here keep the M0 import boundary free of both optional dependencies.
"""

from __future__ import annotations

from pathlib import Path

from ..errors import UnsupportedError
from ..profiler.base import MeasurementPolicy, ProfileRunner
from .model import (
    BenchmarkFingerprint,
    CanonicalAttribute,
    MeasurementOrigin,
    ProfileMeasurement,
    ProfileRequirement,
    ProfileSnapshot,
    TileOpMeasurement,
    TileOpProfileKey,
    TileOpProfileQuery,
    TileOpSignature,
    profile_key_from_json,
    profile_key_to_json,
    profile_query_canonical_json,
    tile_op_signature,
)


class SqliteProfileStore:
    """Placeholder for the M3 transactional profile store."""

    def close(self) -> None:
        return None

    def __enter__(self) -> "SqliteProfileStore":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


class LocalCudaProfileRunner:
    """Lazy CUDA runner placeholder; importing it never imports CUDA Python."""

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir

    def run(self, *_args: object, **_kwargs: object) -> object:
        raise UnsupportedError("local CUDA profiling is scheduled for M3")


def open_profile_store(path: Path, *, writable: bool) -> SqliteProfileStore:
    del path, writable
    raise UnsupportedError("SQLite profile storage is scheduled for M3")


__all__ = [
    "BenchmarkFingerprint",
    "CanonicalAttribute",
    "LocalCudaProfileRunner",
    "MeasurementOrigin",
    "MeasurementPolicy",
    "ProfileMeasurement",
    "ProfileRequirement",
    "ProfileRunner",
    "ProfileSnapshot",
    "TileOpMeasurement",
    "TileOpProfileKey",
    "TileOpProfileQuery",
    "TileOpSignature",
    "profile_key_from_json",
    "profile_key_to_json",
    "profile_query_canonical_json",
    "tile_op_signature",
    "SqliteProfileStore",
    "open_profile_store",
]
