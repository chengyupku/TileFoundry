"""Implementation/provider pair protocols for M2.

The aliases are intentionally defined in ``tileop`` so all constructors share
one owning type.  This module is the stable import location promised by the
development plan.
"""

from __future__ import annotations

from ..profiler.base import CudaBenchmarkProvider
from ..tileop import (
    LoweredTileOp,
    LoweringContext,
    TileOpImplementation,
    TileOpLowering,
)

__all__ = [
    "CudaBenchmarkProvider",
    "LoweredTileOp",
    "LoweringContext",
    "TileOpImplementation",
    "TileOpLowering",
]
