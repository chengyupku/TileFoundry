"""Operation implementation catalog boundary reserved for M2."""

from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class ImplementationCatalog:
    """Container for explicitly installed operation implementations."""

    implementations: tuple[object, ...] = ()


def b200_implementation_catalog() -> ImplementationCatalog:
    """Return an empty catalog until operation lowering lands in M2."""

    return ImplementationCatalog()


__all__ = ["ImplementationCatalog", "b200_implementation_catalog"]
