"""Command-line boundary for ``tilefoundry-costmodel``.

The command names and exit-code mapping are established in M0.  Operations that
need typed lowering, SQLite profiles, CUDA, or a solver report the explicit
unsupported capability until their milestone is implemented.
"""

from __future__ import annotations

import argparse
import sys
from pathlib import Path
from typing import Sequence

from . import (
    CostModelError,
    EvaluationStatus,
    InvalidRequestError,
    MissingProfileError,
    ProfileRunError,
    UnsupportedError,
    __version__,
    problem_from_json,
    request_from_json,
    result_to_json,
    solve,
)
from .profiles.store import open_profile_store


def _parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(
        prog="tilefoundry-costmodel", description="TileFoundry B200 cost model"
    )
    parser.add_argument("--version", action="version", version=__version__)
    sub = parser.add_subparsers(dest="command")

    build_parser = sub.add_parser("build", help="build a replayable search problem")
    _request_profiles_output(build_parser, require_output=True)

    solve_parser = sub.add_parser("solve", help="solve a replayable search problem")
    solve_parser.add_argument("--problem", required=True, type=Path)
    solve_parser.add_argument("--output", required=True, type=Path)

    search_parser = sub.add_parser("search", help="build and solve a request")
    _request_profiles_output(search_parser, require_output=True)

    profile_parser = sub.add_parser("profile", help="measure missing profiles on a local B200")
    _request_profiles_output(profile_parser, require_output=False)

    profiles_parser = sub.add_parser("profiles", help="inspect profile snapshots")
    profiles_sub = profiles_parser.add_subparsers(dest="profiles_command")
    export_parser = profiles_sub.add_parser("export")
    export_parser.add_argument("--profiles", required=True, type=Path)
    export_parser.add_argument("--snapshot", required=True)
    export_parser.add_argument("--output", required=True, type=Path)
    import_parser = profiles_sub.add_parser("import")
    import_parser.add_argument("--profiles", required=True, type=Path)
    import_parser.add_argument("snapshot", type=Path)
    inspect_parser = profiles_sub.add_parser("inspect")
    inspect_parser.add_argument("--profiles", required=True, type=Path)
    inspect_parser.add_argument("--snapshot", required=True)
    return parser


def _request_profiles_output(parser: argparse.ArgumentParser, *, require_output: bool) -> None:
    parser.add_argument("--request", required=True, type=Path)
    parser.add_argument("--profiles", required=True, type=Path)
    parser.add_argument("--output", required=require_output, type=Path)


def main(argv: Sequence[str] | None = None) -> int:
    args = _parser().parse_args(argv)
    if args.command is None:
        _parser().print_help()
        return 0
    try:
        if args.command == "solve":
            return _run_solve(args)
        if args.command in {"build", "search", "profile"}:
            return _run_request_command(args)
        if args.command == "profiles":
            return _run_profiles(args)
        raise InvalidRequestError(f"unknown command: {args.command}")
    except MissingProfileError as exc:
        print(str(exc), file=sys.stderr)
        return 3
    except UnsupportedError as exc:
        print(str(exc), file=sys.stderr)
        return 3
    except ProfileRunError as exc:
        print(str(exc), file=sys.stderr)
        return 4
    except (InvalidRequestError, CostModelError, OSError, ValueError) as exc:
        print(str(exc), file=sys.stderr)
        return 2


def _run_solve(args: argparse.Namespace) -> int:
    problem = problem_from_json(args.problem.read_text(encoding="utf-8"))
    result = solve(problem)
    args.output.write_text(result_to_json(result), encoding="utf-8")
    if result.status in (EvaluationStatus.OPTIMAL, EvaluationStatus.FEASIBLE):
        return 0
    if result.status in (EvaluationStatus.UNSUPPORTED, EvaluationStatus.MISSING_PROFILE):
        return 3
    if result.status is EvaluationStatus.PROFILE_FAILED:
        return 4
    if result.status is EvaluationStatus.INFEASIBLE:
        return 5
    if result.status is EvaluationStatus.TIMEOUT:
        return 0 if result.plan is not None else 6
    raise CostModelError(f"unhandled result status: {result.status.value}")


def _run_request_command(args: argparse.Namespace) -> int:
    request_from_json(args.request.read_text(encoding="utf-8"))
    if args.command == "profile":
        raise UnsupportedError("profile requires the M3 CUDA runner")
    with open_profile_store(args.profiles, writable=False) as store:
        del store
        raise UnsupportedError("build/search require the M2-M4 catalogs")


def _run_profiles(args: argparse.Namespace) -> int:
    del args
    raise UnsupportedError("profile-store commands are scheduled for M3")


if __name__ == "__main__":  # pragma: no cover
    raise SystemExit(main())


__all__ = ["main"]
