"""Profile-store and runner boundary types.

SQLite persistence and CUDA measurement are intentionally deferred to M3. The
types here keep the M0 import boundary free of both optional dependencies.
"""

from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Protocol

from ..errors import UnsupportedError
from .model import MeasurementOrigin, ProfileMeasurement, ProfileSnapshot, TileOpMeasurement


class SqliteProfileStore:
    """Placeholder for the M3 transactional profile store."""

    def close(self) -> None:
        return None

    def __enter__(self) -> "SqliteProfileStore":
        return self

    def __exit__(self, *_args: object) -> None:
        self.close()


@dataclass(frozen=True, slots=True)
class MeasurementPolicy:
    warmup_runs: int = 20
    sample_count: int = 100
    target_sample_ns: int = 100_000
    max_repetitions_per_sample: int = 1_000_000
    max_relative_iqr_ppm: int = 50_000
    retain_raw_samples: bool = False


class ProfileRunner(Protocol):
    """Runner-neutral profile protocol reserved for M3."""


class LocalCudaProfileRunner:
    """Lazy CUDA runner placeholder; importing it never imports CUDA Python."""

    def __init__(self, cache_dir: Path | None = None) -> None:
        self.cache_dir = cache_dir

    def run(self, *_args: object, **_kwargs: object) -> object:
        raise UnsupportedError("local CUDA profiling is scheduled for M3")


def open_profile_store(path: Path, *, writable: bool) -> SqliteProfileStore:
    del path, writable
    raise UnsupportedError("SQLite profile storage is scheduled for M3")


__all__ = [
    "LocalCudaProfileRunner",
    "MeasurementOrigin",
    "MeasurementPolicy",
    "ProfileMeasurement",
    "ProfileRunner",
    "ProfileSnapshot",
    "TileOpMeasurement",
    "SqliteProfileStore",
    "open_profile_store",
]
